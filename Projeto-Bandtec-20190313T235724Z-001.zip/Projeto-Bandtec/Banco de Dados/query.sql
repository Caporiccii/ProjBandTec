create table Supervisor(
idSuper int primary key identity,
nome varchar(30),
DataNasc varchar (10),
CPF varchar(12),
Celular varchar (15),
idUsuario int references Usuario (idUsu)
);
insert into Supervisor values ('Rodolfo','11-09-1980','123456789-09','(11)91234-5678',3),
('marco','18-05-1995','749283172-30','(11)98765-4321',4),
('Godofredo','24-07-1986','912843791-19','(11)94321-5678',5),
('Rosana','31-08-2000','987654321-32','(11)91357-2468',6)
select * from Supervisor;

create table Funcionario(
idFunc int primary key identity,
nome varchar (30),
DataNasc varchar (10),
CPF varchar (12),
Celular varchar (15),
idUsuario int references Usuario (idUsu)
);
insert into Funcionario values ('Rodolfo','11-09-1980','123456789-09','(11)91234-5678',3),
('marco','18-05-1995','749283172-30','(11)98765-4321',4),
('Godofredo','24-07-1986','912843791-19','(11)94321-5678',5),
('Rosana','31-08-2000','987654321-32','(11)91357-2468',6)
select * from Funcionario

create table Usuario(
idUsu int primary key identity,
nomeUsu varchar (30),
senha varchar (100),
nivelAcesso varchar (10)
);
insert into Usuario values('Rodolfo','Rodolfinho13','Máximo'),('Marco','Marcola22','Mínimo')
insert into Usuario values('Godofredo','Jubileu24','Máximo'),('Rosana','Rosinha','Mínimo')
select * from Usuario

create table Temperatura(
idTemp int primary key identity,
Valor int,
Dia_Semana varchar (7),
Dia int,
Hora varchar (8)
);
insert into Temperatura values(24,'Segunda',3,'12:35:37')
select * from Temperatura

create table Umidade(
idUmi int primary key identity,
Valor int,
Dia_Semana varchar (7),
Dia int,
Hora varchar (8)
);
insert into Umidade values(50,'Quarta',5,'15:48:19')
select * from Umidade